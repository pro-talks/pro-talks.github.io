package pro.java.generic;

import org.junit.Test;
import pro.java.generic.domain.ArrayBuilder;
import pro.java.generic.domain.MyNode;
import pro.java.generic.domain.Node;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class ErasureTest {

    @Test
    public void heapPollution() {
        MyNode mn = new MyNode(5);
        Node n = mn;
        //n.setData("Hello");  // Unchecked warning
        Integer x = mn.data;

        //Find methods with reflection
        for (Method method : MyNode.class.getMethods()) {
            if (!Objects.equals(method.getName(), "setData")) continue;
            System.out.println("Method's name: " + method.getName() +
                    ". Parameters: " + Arrays.toString(method.getParameters()) +
                    ". Is it synthetic: " + method.isSynthetic());
        }
    }

    @Test(expected = ClassCastException.class)
    public void heapPollution2() {
        List<String> stringListA = new ArrayList<>();
        List<String> stringListB = new ArrayList<>();

        ArrayBuilder.addToList(stringListA, "Seven", "Eight", "Nine");
        ArrayBuilder.addToList(stringListB, "Ten", "Eleven", "Twelve");
        List<List<String>> listOfStringLists = new ArrayList<>();
        ArrayBuilder.addToList(listOfStringLists, stringListA, stringListB);

        ArrayBuilder.faultyMethod(Arrays.asList("Hello!"), Arrays.asList("World!"));
    }
}