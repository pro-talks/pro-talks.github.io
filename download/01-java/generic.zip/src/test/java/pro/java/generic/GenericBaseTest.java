package pro.java.generic;

import org.junit.Test;
import pro.java.generic.domain.Box;
import pro.java.generic.domain.GenericBox;
import pro.java.generic.domain.GenericMethod;
import pro.java.generic.domain.T;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericBaseTest {

    @Test
    public void casting() {
        //without generic
        List list = new ArrayList();
        list.add("hello");
        String s = (String) list.get(0);

        //with generic
        List<String> list2 = new ArrayList<>();
        list2.add("hello");
        String s2 = list2.get(0); //no cast
    }

    @Test(expected = ClassCastException.class)
    public void checkingWhileCompile() {
        //with generic
        List<String> list2 = new ArrayList<>();
        list2.add("hello");
        //list2.add(1); //not compile
        String s3 = list2.get(0);

        //without generic
        List list = new ArrayList();
        list.add("hello");
        list.add(1);
        String s = (String) list.get(0);
        String s2 = (String) list.get(1); //runtime error -> ClassCastException
    }

    @Test
    public void nested() {
        GenericBox<GenericBox<GenericBox<?>>> box = new GenericBox<>();
        box.setValue(new GenericBox<>());
    }

    @Test
    public void genericClass() {
        GenericBox<Integer> box = new GenericBox<>();
        box.setValue(10);
        Integer value = box.getValue();

        assertEquals(value, new Integer(10));
    }

    @Test
    public void commonClass() {
        Box box = new Box();
        box.setValue(10);
        Integer value = (Integer) box.getValue();

        assertEquals(value, new Integer(10));
    }

    @Test
    public void uncheckedWarnings() {
        List rawList = new ArrayList();
        List<String> list = new ArrayList<>();

        rawList = list; //OK
        list = rawList; //Warning

        String s = rawList.toString(); //OK
        rawList.add("test"); //Warning
    }

    @Test
    public void uncheckedWarning2(){
        Map<String, String> myMap = new HashMap(); // unchecked conversion warning
        Map<String, String> myMap2 = new HashMap<>();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void ignoreUncheckedWarnings() {
        GenericBox rawBox = new GenericBox();
        rawBox.setValue(10); //unchecked warning
        GenericBox<Integer> genericBox = rawBox; //unchecked warning
        GenericBox rawBox2 = genericBox; //No unchecked warning
    }

    @Test
    public void genericMethods() {
        //static
        GenericMethod.staticPrint("1", "2", 3);
        //non-static
        GenericMethod genericMethod = new GenericMethod();
        genericMethod.nonStaticPrint("4", "5", 6);
        //constructor
        GenericMethod genericMethod2 = new GenericMethod("7", 8, 9);
        genericMethod2.print();
    }

    @Test
    public void notGenericMethod() {
        print(new T(), new T(), new T());
    }

    private static void print(T t, T u, T v) {
        System.out.println(String.format("t is %s, u is %s, v is %s", t, u, v));
    }

    @Test
    public void inheritance(){
        someMethod(new Integer(10));   // OK
        someMethod(new Double(10.1));   // OK
    }

    public void someMethod(Number n) { /* ... */ }

    @Test
    public void inheritance2() {
        GenericBox<Integer> box = new GenericBox<>();
        box.setValue(Integer.MAX_VALUE);
        //boxTest(box);
        boxTestWildcard(box);
    }

    public void boxTest(GenericBox<Number> n) { /* ... */ }
    public void boxTestWildcard(GenericBox<? extends Number> n) { /* ... */ }

}
