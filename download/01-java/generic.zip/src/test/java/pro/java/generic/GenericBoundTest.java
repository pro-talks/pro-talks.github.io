package pro.java.generic;

import org.junit.Test;
import pro.java.generic.domain.CompareBox;
import pro.java.generic.domain.DiffParameterTypeInClass;
import pro.java.generic.domain.GenericBox;
import pro.java.generic.domain.SumBox;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericBoundTest {

    @Test
    public void boundExtend() {
        SumBox<Integer, Integer> integerBox = new SumBox<>(Integer.valueOf(5), Integer.valueOf(10));
        int sum = integerBox.sum();
        assertEquals(15, sum);
    }

    @Test
    public void multiBounds() {
        List<Integer> integers = Arrays.asList(5, 6, 7);
        CompareBox<Integer> compareBox1 = new CompareBox<>(integers);
        assertEquals(Optional.of(5), compareBox1.min());
        assertEquals(Optional.of(7), compareBox1.max());

        List<Double> doubles = Arrays.asList(5.0, 6.2, 7.2);
        CompareBox<Double> compareBox2 = new CompareBox<>(doubles);
        assertEquals(Optional.of(5.0), compareBox2.min());
        assertEquals(Optional.of(7.2), compareBox2.max());
    }

    @Test
    public void methodWithCompare() {
        Integer[] integers = (Integer[]) Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9).toArray();
        assertEquals(4, countGreaterThan(integers, 5));

    }

    private <T extends Comparable<T>> int countGreaterThan(T[] anArray, T elem) {
        int count = 0;
        for (T e : anArray)
            if (e.compareTo(elem) > 0)
                ++count;
        return count;
    }

    @Test
    public void genericMethod1() {
        GenericBox<Integer> box = new GenericBox<>();
        boxTest(box);
        GenericBox<Double> box2 = new GenericBox<>();
        boxTest(box2);
    }

    private void boxTest(GenericBox<? extends Number> box) { //GenericBox<Number> not compile
        System.out.println(box.getValue());
    }

    @Test
    public void genericMethod2() {
        Serializable s = pick("d", new ArrayList<String>());
    }

    <T> T pick(T a1, T a2) {
        return a2;
    }

    @Test
    public void diffParameterTypesInClass() {
        DiffParameterTypeInClass<Integer> myObject = new DiffParameterTypeInClass<>("test");
        Integer n = myObject.test(1);
        assertEquals(new Integer(1), n);
    }

    @Test
    public void genericMethod3() {
        processStringList(Collections.emptyList());
        //processStringList(Collections.<String>emptyList()); --for java7
    }

    void processStringList(List<String> stringList) {
        for (String s : stringList) {
            System.out.println("");
        }
        // process stringList
    }

    @Test
    public void genericMethod4() {
        List<Integer> intList = Collections.emptyList();
        //printList(intList); // Compile-time error

        printList(Collections.emptyList()); //OK
    }

    public void printList(List<Object> list) {
        for (Object elem : list)
            System.out.println(elem + " ");
        System.out.println();
    }

    @Test
    public void genericVSWildcard() {
        List<Integer> integers = new ArrayList<>(Arrays.asList(1, 2, 3));
        List<Number> numbers = new ArrayList(Arrays.asList(1, 2, 3));
        List<Double> doubles = new ArrayList<>(Arrays.asList(1.0, 2.2, 3.3));

        getCollection(integers);
        getCollection(numbers);
        getCollection(doubles);

        getCollection2(integers);
        getCollection2(numbers);
        getCollection2(doubles);
    }

    private <T extends Number> void getCollection(List<T> list) {
        list.forEach(System.out::println);
        list.add((T) new Double(123.0)); //possible add item
    }

    private void getCollection2(List<? extends Number> list) {
        list.forEach(System.out::println);
        //list.add(new Double(123.0)); //not possible add item
    }
}
