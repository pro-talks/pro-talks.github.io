package pro.java.generic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author Serzh Nosov created on 28.10.2019.
 */
public class GenericHeapPollution {

    //@Test(expected = ClassCastException.class)
    public void heapPollution1() {
        faultyMethod(Arrays.asList("Hello!"), Arrays.asList("World!"));
    }

    @SafeVarargs
    public static void faultyMethod(List<String>... l) {
        Object[] objectArray = l;     // Valid
        objectArray[0] = Arrays.asList(42);
        String s = l[0].get(0);       // ClassCastException thrown here
    }

}
