package pro.java.generic;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericLimitationArrayCreationTest {

    @Test(expected = ArrayStoreException.class)
    public void genericWithArray1() {
        Object[] strings = new String[2];
        strings[0] = "hi";   // OK
        strings[1] = 100;    // An ArrayStoreException is thrown. It calls "dynamically checked"
    }

    @Test
    public void genericWithArray2() {
        List list = new ArrayList<String>();
        list.add("hi"); // OK
        list.add(100);  // OK, no StoreException -> it calls, "not dynamically checked"
    }

    @Test(expected = ClassCastException.class)
    public void genericWithArray3() {
        List<Integer> li = new ArrayList<>();
        li.add(new Integer(3));

        // Example with collection
        List<List<String>> lsa = new ArrayList<>();
        lsa.add(Collections.singletonList("a"));
        List oa = lsa;  // Ok, also it doesn't throw unchecked warning!
        oa.set(0, li); // Generics, which are statically sound -> Throw unchecked warning -> Java says, that you could get an exception
        String s1 = lsa.get(0).get(0); // Throws ClassCastException
    }

    @Test(expected = ClassCastException.class)
    public void genericWithArray4() {
        List<Integer> li = new ArrayList<Integer>();
        li.add(new Integer(3));

        List<String>[] lsa = new List[10]; //Throw unchecked warning -> Java says, that you could get an exception
        // List<String>[] lsa = new List<String>[10]; // illegal
        // You can use generic with arrays, but you will get warning in the first line, in the creation line
        List[] oa = lsa;  // OK because List<String> is a subtype of Object
        oa[0] = li; //!!! Arrays "dynamically checked" -> An ArrayStoreException should be thrown, but the runtime can't detect it.
        String s = lsa[0].get(0);
    }

    @Test
    public void genericWithArray5() {
        List<?>[] arr = new ArrayList<?>[10];
        arr[0] = new ArrayList<String>(); //OK
        arr[1] = new ArrayList<Integer>(); //OK
        //arr[2] = Collections.singletonList(1); // throws java.lang.ArrayStoreException: java.util.Collections$SingletonList
        //arr[3] = Arrays.asList("a"); // throws java.lang.ArrayStoreException: java.util.Arrays$ArrayList

        //Array checks that all values have type ArrayList
    }

    @Test
    public void examples() {
        //List<String>[] arr = new List<String>[3];
        List<String>[] arr = new List[3];
        arr[0] = Arrays.asList("a");
        String s = arr[0].get(0);
    }

    /**
     * If the component type of an array were not reifiable (§4.7),
     * the Java Virtual Machine could not perform the store check described in the preceding paragraph.
     * This is why an array creation expression with a non-reifiable element type is forbidden (§15.10).
     * One may declare a variable of an array type whose element type is non-reifiable,
     * but assignment of the result of an array creation expression
     * to the variable will necessarily cause an unchecked warning (§5.1.9).
     *
     * https://docs.oracle.com/javase/specs/jls/se7/html/jls-10.html
     */
}