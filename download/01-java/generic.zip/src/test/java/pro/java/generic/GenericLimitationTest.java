package pro.java.generic;

import org.junit.Test;
import pro.java.generic.domain.Pair;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericLimitationTest {

    //private static TTT t; //not compile

    @Test
    public void genericLimitation1() {
        //Pair<int, char> p = new Pair<>(8, 'a'); compile-error
        Pair<Integer, Character> p = new Pair<>(8, 'a');
    }

    @Test
    public void genericLimitation2() throws Exception {
        List<String> list = new ArrayList<>();
        append(list, String.class);
    }

    public static <E> void append(List<E> list) {
        //E elem = new E();  // compile-time error
        //list.add(elem);
    }

    private static <E> void append(List<E> list, Class<E> cls) throws Exception {
        E elem = cls.newInstance();   // OK
        list.add(elem);
    }

    @Test
    public void genericLimitation3() throws Exception {
        List<String> list = new ArrayList<>();
        rtti(list);
        rtti2(list);
    }

    public static <E> void rtti(List<E> list) {
        //if (list instanceof ArrayList<Integer>) {  // compile-time error
        // ...
        //}
    }

    public static void rtti2(List<?> list) {
        if (list instanceof ArrayList<?>) {  // OK; instanceof requires a reifiable type
            // ...
        }
    }

    @Test(expected = ClassCastException.class)
    public void genericLimitation4() throws Exception {
        //List<Integer> li = new ArrayList<>();
        //List<Number>  ln = (List<Number>) li;  // compile-time error

        List<String> l1 = new LinkedList<>();
        ArrayList<String> l2 = (ArrayList<String>)l1;  // java.lang.ClassCastException:
    }

    @Test
    public <T extends Exception, J> void genericLimitation5() throws Exception {
        execute(new ArrayList<>());
    }

    public static <T extends Exception, J> void execute(List<J> jobs) {
        /*try {
            for (J job : jobs) {
            }
            // ...
        } catch (T e) {   // Compile-time error
            // ...
        }*/
    }

    @Test
    public <T extends Exception, J> void genericLimitation6() throws Exception {
        execute(new ArrayList<>());
    }
}

class Parser<T extends Exception> {

    public <J extends Exception> void parse(File file) throws T, J { // OK
        // ...
    }
}

/*public class Example {
    public void print(Set<String> strSet) { }
    public void print(Set<Integer> intSet) { }
}*/

// Extends Throwable indirectly
//class MathException<T> extends Exception { /* ... */ }    // compile-time error

// Extends Throwable directly
//class QueueFullException<T> extends Throwable { /* ... */ // compile-time error
