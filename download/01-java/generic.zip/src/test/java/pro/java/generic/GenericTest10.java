package pro.java.generic;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericTest10 {

    @Test(expected = ClassCastException.class)
    public void startGeneric2() {
        final String s = getList();
    }

    public static <T extends List<Integer>> T getList() {
        return (T) new ArrayList<Integer>();
    }
}
