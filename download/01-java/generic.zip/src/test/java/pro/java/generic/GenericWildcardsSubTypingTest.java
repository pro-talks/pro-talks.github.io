package pro.java.generic;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericWildcardsSubTypingTest {

    /**
     * Wildcard - Проблема совместимости
     */

    @Test
    public void theIssue() {
        Integer integer = 1;
        Number number = integer;

        List<Integer> intList = new ArrayList<>();
        //List<Number> numList = intList;   // compile error
    }

    @Test
    public void theDecision() {
        List<? extends Integer> intList = new ArrayList<>();
        List<? extends Number> numList = intList;  // OK
    }
}