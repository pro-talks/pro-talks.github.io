package pro.java.generic;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static junit.framework.TestCase.assertEquals;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericWildcardsTest {

    /**
     * GENERIC - Unbounded - Проблема совместимости
     */

    @Test
    public void why() {
        List<Integer> collect = IntStream.range(1, 9).boxed().collect(Collectors.toList());
        printCollectionBeforeGeneric(collect);
        //issue_printCollectionAfterGeneric(collect); // Compile error
        decision_printCollectionAfterGeneric(collect); // OK
    }

    private void printCollectionBeforeGeneric(Collection collection) {
        for (Object o : collection) {
            System.out.println(o);
        }
    }

    private void issue_printCollectionAfterGeneric(Collection<Object> collection) {
        for (Object o : collection) {
            System.out.println(o);
        }
    }

    private void decision_printCollectionAfterGeneric(Collection<?> collection) {
        for (Object o : collection) {
            System.out.println(o);
        }
    }

    /**
     * GENERIC - Unbounded
     */

    @Test
    public void unboundedWildcards2() {
        List<?> list = new ArrayList<>();
        //list.add(new Object()); //compile error
    }

    @Test
    public void unboundedWildcards3() {
        List<?> list = new ArrayList<>(Arrays.asList(1, 2, 3));
        list.add(null); //OK
        list.removeIf(i -> Objects.equals(i, 1)); //OK

        System.out.println(Arrays.toString(list.toArray()));

        theHelper(list);

        System.out.println(Arrays.toString(list.toArray()));

        list.clear(); //OK

        System.out.println(Arrays.toString(list.toArray()));
    }

    public <T> void theHelper(List<T> list) {
        list.set(0, list.get(1));  //OK
        list.add(list.get(1)); //OK
        list.add((T) new Double(8.0)); //OK, but unchecked warning
    }

    /**
     * WILDCARDS - Upper Bounded
     */

    @Test
    public void upperBoundedWildcards() {
        List<Integer> li = Arrays.asList(1, 2, 3);
        assertEquals(6.0, sumOfList(li));

        List<Double> ld = Arrays.asList(1.2, 2.3, 3.5);
        assertEquals(7.0, sumOfList(ld));
    }

    private double sumOfList(List<? extends Number> list) {
        double s = 0.0;
        for (Number n : list)
            s += n.doubleValue();
        return s;
    }

    @Test
    public void upperBoundedWildcards2() {
        List<? extends Number> list = new ArrayList<>();
        //list.add(new Integer(1)); //compile error
    }

    @Test
    public void upperBoundedWildcards3() {
        List<? extends Number> list = new ArrayList<>(Arrays.asList(1, 2, 3));
        list.add(null); //OK
        list.removeIf(i -> Objects.equals(i, 1)); //OK

        System.out.println(Arrays.toString(list.toArray()));

        theHelper(list);

        System.out.println(Arrays.toString(list.toArray()));

        list.clear(); //OK

        System.out.println(Arrays.toString(list.toArray()));
    }

    /**
     * WILDCARDS - Lower Bounded
     */

    @Test
    public void lowerBoundedWildcards() {
        List<Integer> integers = new ArrayList<>();
        List<Number> numbers = new ArrayList<>();
        List<Object> objects = new ArrayList<>();

        addNumbers(integers);
        assertEquals("[1, 2, 3]", Arrays.toString(integers.toArray()));

        addNumbers(numbers);
        assertEquals("[1, 2, 3]", Arrays.toString(integers.toArray()));

        addNumbers(objects);
        assertEquals("[1, 2, 3]", Arrays.toString(integers.toArray()));
    }

    private void addNumbers(Collection<? super Integer> list) {
        for (int i = 1; i <= 3; i++) {
            list.add(i);
        }
    }

    @Test
    public void lowerBoundedWildcards2() {
        List<? super Integer> integers = new ArrayList<>(Arrays.asList(1, 2, 3));

        integers.add(6);

        System.out.println(Arrays.toString(integers.toArray()));

        Object object = integers.get(1);
    }

    /**
     * WILDCARDS - Comparing 3 Types
     */

    @Test
    public void compareWildcards() {
        List<Number> integers = IntStream.range(1, 9).boxed().collect(Collectors.toList());

        List<? super Number> lowerBoundedWildcard = integers;
        List<?> unboundedWildcard = integers;
        List<? extends Number> upperBoundedWildcard = integers;

        integers.add(1); // OK
        Number number1 = integers.get(0); // OK

        /* WILDCARDS */

        lowerBoundedWildcard.add(1); // OK
        Object object1 = lowerBoundedWildcard.get(0); // OK, but cast to Object

        //unboundedWildcard.add(new Object()); // compile error
        Object object2 = unboundedWildcard.get(0);

        //upperBoundedWildcard.add(1); // compile error
        Number number2 = upperBoundedWildcard.get(0);
    }
}
