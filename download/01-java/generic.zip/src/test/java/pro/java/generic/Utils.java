package pro.java.generic;

import org.apache.log4j.Logger;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class Utils {

    static Logger log = Logger.getLogger(Utils.class.getName());

    public static void titleInLog(String message) {
        log.info("");
        log.info("");
        log.info(message.toUpperCase());
    }
}
