package pro.java.generic;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class WildcardCaptureTest {

    /**
     * Example 1
     */

    @Test
    public void wildcardCapture() {
        List<?> list = new ArrayList<>(Arrays.asList(1, "2", 3.0));

        //list.set(0, list.get(0)); //compile error -> capture<?>
        wildcardCaptureHelper(list);
    }

    private <T> void wildcardCaptureHelper(List<T> l) {
        l.set(0, l.get(0)); //l.set(0, l.get(2));
        l.add(l.get(0));
        System.out.println(Arrays.toString(l.toArray()));
    }

    /**
     * Example 2
     */

    @Test
    public void theIssue2() {
        List<Integer> li = Arrays.asList(1, 2, 3);
        List<Double> ld = Arrays.asList(10.10, 20.20, 30.30);
        swapFirst(li, ld);
    }

    void swapFirst(List<? extends Number> l1, List<? extends Number> l2) {
        Number temp = l1.get(0);
        //l1.set(0, l2.get(0)); // compile error
        //l2.set(0, temp); // compile error
    }

    /**
     * Example 3
     */

    @Test
    public void test3() {
        Collection<? extends String> list = new ArrayList<>();
        //list.add(""); compile error
    }
}
