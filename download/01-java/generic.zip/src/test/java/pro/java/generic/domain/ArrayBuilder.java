package pro.java.generic.domain;

import java.util.Arrays;
import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class ArrayBuilder {

    public static <T> void addToList (List<T> listArg, T... elements) {
        for (T x : elements) {
            listArg.add(x);
        }
    }

    @SafeVarargs
    //@SuppressWarnings("unchecked")
    public static void faultyMethod(List<String>... l) {
        Object[] objectArray = l;     // Valid
        objectArray[0] = Arrays.asList(42);
        String s = l[0].get(0);       // ClassCastException thrown here
    }
}
