package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class Box {

    private Object value;

    public void setValue(Object o) {
        this.value = o;
    }

    public Object getValue() {
        return this.value;
    }
}
