package pro.java.generic.domain;

import java.util.Collection;
import java.util.Optional;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class CompareBox<T extends Number & Comparable> {

    private Collection<T> collection;

    public CompareBox(Collection<T> collection) {
        this.collection = collection;
    }

    public Optional<T> max() {
        return collection.stream().max(Comparable::compareTo);
    }

    public Optional<T> min() {
        return collection.stream().min(Comparable::compareTo);
    }
}
