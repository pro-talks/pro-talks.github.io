package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class DiffParameterTypeInClass<X> {
    public <T> DiffParameterTypeInClass(T t) {
        System.out.printf(t.toString());
    }

    public <K> K test(K t) {
        return t;
    }
}
