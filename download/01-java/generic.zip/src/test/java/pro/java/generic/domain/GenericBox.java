package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericBox<T> {

    private T value;

    public void setValue(T o) {
        this.value = o;
    }

    public T getValue() {
        return this.value;
    }
}