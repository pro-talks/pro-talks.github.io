package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class GenericMethod {

    private Object t;
    private Object u;
    private Object v;

    public GenericMethod() {
    }

    public <T, U, V> GenericMethod(T t, U u, V v) {
        this.t = t;
        this.u = u;
        this.v = v;
    }

    public static <T, U, V> void staticPrint(T t, U u, V v) {
        System.out.println(String.format("t is %s, u is %s, v is %s", t, u, v));
    }

    public <T, U, V> void nonStaticPrint(T t, U u, V v) {
        System.out.println(String.format("t is %s, u is %s, v is %s", t, u, v));
    }

    public void print() {
        System.out.println(String.format("t is %s, u is %s, v is %s", t, u, v));
    }
}
