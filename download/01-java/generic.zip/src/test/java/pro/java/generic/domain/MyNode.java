package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class MyNode extends Node<Integer> {
    public MyNode(Integer data) { super(data); }

    public void setData(Integer data) {
        System.out.println("MyNode.setData");
        super.setData(data);
    }
}
