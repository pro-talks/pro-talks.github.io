package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class Node<T> {

    public T data;

    public Node(T data) { this.data = data; }

    public void setData(T data) {
        System.out.println("Node.setData");
        this.data = data;
    }
}
