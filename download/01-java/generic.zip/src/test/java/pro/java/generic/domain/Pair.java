package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 28.10.2019.
 */
public class Pair<K, V> {

    private K key;
    private V value;

    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    // ...
}
