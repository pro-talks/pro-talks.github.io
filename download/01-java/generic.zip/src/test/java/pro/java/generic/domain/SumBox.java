package pro.java.generic.domain;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class SumBox<T extends Integer, U extends Integer> {

    private T t;
    private U u;

    public SumBox(T t, U u) {
        this.t = t;
        this.u = u;
    }

    public int sum() {
        return Integer.sum(t.intValue(), u.intValue());
        //return t + u; //warning, but compile!
    }
}
