package pro.java.generic.domain;

import java.util.List;

/**
 * @author Serzh Nosov created on 25.10.2019.
 */
public class WildCardBox {

    List<? extends String> list; //field

    public WildCardBox(List<? extends String> list) { //in argument
        List<? extends String> localVariable = list; //local variable
        this.list = localVariable;
    }

    public List<? extends String> getList() { //return value
        return list;
    }
}

class WildCardBoxForbidden {

    public static void forbidden(String[] args) {
        //Arrays.<?>asList(1, "", '5');
        //List<?> list = new ArrayList<?>();
    }
}