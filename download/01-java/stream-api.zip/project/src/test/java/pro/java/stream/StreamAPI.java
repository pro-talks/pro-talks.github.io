package pro.java.stream;

import org.junit.BeforeClass;
import org.junit.Test;
import pro.java.stream.domain.Group;
import pro.java.stream.domain.People;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.util.Comparator.comparing;
import static org.junit.Assert.assertEquals;
import static pro.java.stream.Utils.titleInLog;

public class StreamAPI {

    private static List<People> people;

    @BeforeClass
    public static void beforeClass() {
        Group odd = new Group("Odd");
        Group even = new Group("Even");
        Group empty = new Group("Empty");

        people = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            People p = new People("name_" + i);
            p.setAge(70 + i);
            people.add(p);
            if (i % 2 == 0) {
                p.setGroup(even);
                even.getPeople().add(p);
            } else {
                p.setGroup(odd);
                odd.getPeople().add(p);
            }
        }
    }

    @Test
    public void testPrintGroupJava7() {
        Set<Group> groups = new HashSet<>();
        for (People p : people) {
            if (p.getAge() >= 65)
                groups.add(p.getGroup());
        }
        List<Group> sorted = new ArrayList<>(groups);
        Collections.sort(sorted, new Comparator<Group>() {
            @Override
            public int compare(Group o1, Group o2) {
                return Integer.compare(o1.getSize(), o2.getSize());
            }
        });
        for (Group g : sorted) {
            System.out.println(g.getName());
        }
    }

    @Test
    public void testPrintGroupJava8() {
        String s = people.stream().parallel()
                .parallel()
                .filter(p -> p.getAge() >= 65)
                .map(People::getGroup)
                .distinct()
                .sorted(comparing(Group::getSize))
                .map(Group::getName)
                .collect(Collectors.joining(", "));

        assertEquals(s, "Even, Odd");
    }

    @Test
    public void testPeek() {
        titleInLog("Peek without terminal operation - не распечатает");
        Stream.of(1, 2, 3).peek(System.out::println);

        titleInLog("Peek with terminal operation - распечатает");
        String s = Stream.of(1, 2, 3)
                .map(Object::toString)
                .peek(System.out::println)
                .collect(Collectors.joining(", "));

        assertEquals(s, "1, 2, 3");
    }

    @Test
    public void testBuilders() {
        String v1 = "one";
        String v2 = "two";
        String v3 = "three";
        String[] arr = {v1, v2, v3};

        // Stream from array
        Stream<String> s1 = Arrays.stream(arr);

        // Stream from values
        Stream<String> s2 = Stream.of(v1, v2, v3);

        // Stream builder
        Stream<Object> s3 = Stream.builder()
                .add(v1).add(v2).add(v3)
                .build();

        // Stream generation
        Stream<Integer> s4 = IntStream.range(1, 4)
                .boxed();

        String s = Stream.of(s1, s2, s3, s4)
                .reduce(Stream::concat)
                .orElseGet(Stream::empty)
                .map(Object::toString)
                .collect(Collectors.joining(", "));

        assertEquals(s, "one, two, three, one, two, three, one, two, three, 1, 2, 3");
    }

    @Test
    public void testGenerators() {
        // Stream.generate
        AtomicInteger init = new AtomicInteger(0);
        Stream<Integer> s1 = Stream.generate(init::getAndIncrement);

        // Stream.iterate
        Stream<Integer> s2 = Stream.iterate(0, i -> i + 1);

        String s = Stream.of(s1, s2)
                .reduce(Stream::concat)
                .orElseGet(Stream::empty)
                .limit(10)
                .map(Object::toString)
                .collect(Collectors.joining(", "));

        assertEquals(s, "0, 1, 2, 3, 4, 5, 6, 7, 8, 9");
    }

    @Test
    public void testFilter() {
        // Посчитать сумму чётных чисел от 0 до 99
        int sum = Stream.iterate(0, i -> i + 1)
                .limit(100)
                .filter(i -> i % 2 == 0) // Predicate<Integer> filter = i -> i % 2 == 0;
                .mapToInt(i -> i)
                //.peek(System.out::println)
                .sum();

        assertEquals(sum, 2450);
    }

    @Test
    public void testMap() {
        // Объединить элементы из вложеных коллекций
        List<List<People>> list = Arrays.asList(people, people);
        long count = list.stream()
                .flatMap(Collection::stream)
                .count();

        assertEquals(count, 20);
    }

    @Test
    public void testSorted() {
        String s = people.stream()
                //.sorted()
                .sorted(comparing(People::getAge))
                .map(p -> String.valueOf(p.getAge()))
                .collect(Collectors.joining(", "));

        assertEquals(s, "70, 71, 72, 73, 74, 75, 76, 77, 78, 79");
    }

    @Test
    public void testDistinct() {
        // Удалить дубликаты в Stream
        List<List<People>> list = Arrays.asList(people, people);
        long count = list.stream()
                .flatMap(Collection::stream)
                .distinct()
                .count();

        assertEquals(count, 10);
    }

    @Test
    public void testLimit() {
        // Обрезать Stream с конца
        String s = people.stream()
                .limit(3)
                .map(People::getName)
                .collect(Collectors.joining(", "));

        assertEquals(s, "name_0, name_1, name_2");
    }

    @Test
    public void testSkip() {
        // Обрезать Stream с начала
        String s = people.stream()
                .skip(3)
                .map(People::getName)
                .collect(Collectors.joining(", "));

        assertEquals(s, "name_3, name_4, name_5, name_6, name_7, name_8, name_9");
    }

    @Test
    public void testUnorderedAndParallel() {
        // Убрать поддержку порядка для многопоточной обработки
        people.stream()
                .parallel()
                .unordered()
                .forEach(p -> System.out.println(p.getName()));
    }

    @Test
    public void testUnorderedAndSequential() {
        // Убрать поддержку порядка для однопоточной обработки
        people.stream()
                .sequential()
                .unordered()
                .forEach(p -> System.out.println(p.getName()));
    }

    @Test(expected = IllegalStateException.class)
    public void testUsageStreamTwice() {
        Stream<People> stream = people.stream();
        stream.peek(p -> System.out.println(p.getName()));
        String s = stream
                .limit(3)
                .map(People::getName)
                .collect(Collectors.joining(", "));

        assertEquals(s, "name_0, name_1, name_2");
    }

    @Test
    public void testStringJoiner() {
        String s1 = people.stream()
                .map(People::getName)
                .limit(3)
                .collect(Collectors.joining(", "));

        assertEquals(s1, "name_0, name_1, name_2");


        StringJoiner s2 = new StringJoiner(", ", "[", "]");
        s2.add("Red").add("Green").add("Blue");

        assertEquals(s2.toString(), "[Red, Green, Blue]");
    }

    @Test
    public void testForEach() {
        Stream<Integer> stream1 = IntStream.range(0, 10000)
                .mapToObj(i -> i);
        System.out.println(getSum(stream1));

        Stream<Integer> stream2 = IntStream.range(0, 10000)
                .mapToObj(i -> i)
                .parallel();
        System.out.println(getSum(stream2));
    }

    private int getSum(Stream<Integer> stream) {
        int[] sum = new int[1];
        stream.forEach(i -> sum[0] += i);
        return sum[0];
    }
}
