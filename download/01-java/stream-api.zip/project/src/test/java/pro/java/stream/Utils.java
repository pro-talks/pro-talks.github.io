package pro.java.stream;

import org.apache.log4j.Logger;

public class Utils {

    static Logger log = Logger.getLogger(Utils.class.getName());

    public static void titleInLog(String message) {
        log.info("");
        log.info("");
        log.info(message.toUpperCase());
    }
}
