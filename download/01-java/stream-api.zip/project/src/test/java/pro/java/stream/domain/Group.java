package pro.java.stream.domain;

import java.util.ArrayList;
import java.util.List;

public class Group {

    private String name;
    private List<People> people;

    public Group(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<People> getPeople() {
        if (people == null) people = new ArrayList<>();
        return people;
    }

    public void setPeople(List<People> people) {
        this.people = people;
    }

    public int getSize() {
        return people.size();
    }
}
