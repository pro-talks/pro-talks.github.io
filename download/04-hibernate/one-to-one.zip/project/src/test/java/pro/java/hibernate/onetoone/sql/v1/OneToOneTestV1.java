package pro.java.hibernate.onetoone.sql.v1;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

import static pro.java.hibernate.onetoone.sql.Utils.titleInLog;

public class OneToOneTestV1 extends TestCase {

    static Logger log = Logger.getLogger(OneToOneTestV1.class.getName());

    private EntityManagerFactory entityManagerFactory;
    private EntityManager em;

    @Override
    protected void setUp() {
        entityManagerFactory = Persistence.createEntityManagerFactory("pro.java.hibernate.one-to-one");
        em = entityManagerFactory.createEntityManager();
    }

    @Override
    protected void tearDown() {
        em.close();
        entityManagerFactory.close();
    }

    @Test
    public void testSavePhone() {
        PhoneV1 phone = new PhoneV1("123-456");
        PhoneDetailsV1 details = new PhoneDetailsV1("important");
        phone.setDetails(details);


        titleInLog("Save phone and details");
        em.getTransaction().begin();
        em.persist(phone);
        em.getTransaction().commit();


        titleInLog("Fetch phone");
        em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        List<PhoneV1> result = em.createQuery("from PhoneV1", PhoneV1.class).getResultList();
        for (PhoneV1 p : result) {
            log.info(p);
        }
        em.getTransaction().commit();


        titleInLog("Fetch phone and details - lazy case");
        em.getTransaction().begin();
        result = em.createQuery("from PhoneV1", PhoneV1.class).getResultList();
        for (PhoneV1 p : result) {
            log.info(p);
            log.info(p.getDetails());
        }
        em.getTransaction().commit();


        titleInLog("Fetch phone and details - query");
        em.getTransaction().begin();
        result = em.createQuery("SELECT DISTINCT p FROM PhoneV1 p INNER JOIN FETCH p.details d", PhoneV1.class).getResultList();
        for (PhoneV1 p : result) {
            log.info(p);
            log.info(p.getDetails());
        }
        em.getTransaction().commit();


        titleInLog("Delete phone and details");
        phone = em.find(PhoneV1.class, phone.getId());
        em.getTransaction().begin();
        em.remove(phone);
        em.getTransaction().commit();
    }
}
