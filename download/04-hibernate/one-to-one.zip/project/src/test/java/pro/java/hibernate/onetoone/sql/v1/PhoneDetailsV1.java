package pro.java.hibernate.onetoone.sql.v1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name = "PhoneDetailsV1")
public class PhoneDetailsV1 {

    @Id
    @GeneratedValue
    private Long id;

    private String description;

    /*for hibernate*/
    public PhoneDetailsV1() {
    }

    public PhoneDetailsV1(String description) {
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "PhoneDetailsV1{" +
                "id=" + id +
                ", description='" + description + '\'' +
                '}';
    }
}
