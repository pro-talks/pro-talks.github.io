package pro.java.hibernate.onetoone.sql.v1;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "PhoneV1")
public class PhoneV1 {

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "number")
    private String number;

    @OneToOne(fetch = FetchType.LAZY,
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    @JoinColumn(name = "details_id")
    private PhoneDetailsV1 details;

    /*for hibernate*/
    public PhoneV1() {
    }

    public PhoneV1(String number) {
        this.number = number;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public PhoneDetailsV1 getDetails() {
        return details;
    }

    public void setDetails(PhoneDetailsV1 details) {
        this.details = details;
    }

    @Override
    public String toString() {
        return "PhoneV1{" +
                "id=" + id +
                ", number='" + number + '\'' +
                '}';
    }
}
