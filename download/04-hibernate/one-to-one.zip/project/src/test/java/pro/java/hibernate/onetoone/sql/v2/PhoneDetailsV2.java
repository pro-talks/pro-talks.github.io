package pro.java.hibernate.onetoone.sql.v2;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "PhoneDetailsV2")
public class PhoneDetailsV2 {

    @Id
    @GeneratedValue
    private Long id;

    private String description;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "phone_id")
    private PhoneV2 phoneV2;

    /*for hibernate*/
    public PhoneDetailsV2() {
    }

    public PhoneDetailsV2(String description) {
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PhoneV2 getPhoneV2() {
        return phoneV2;
    }

    public void setPhoneV2(PhoneV2 phoneV2) {
        this.phoneV2 = phoneV2;
    }

    @Override
    public String toString() {
        return "PhoneDetailsV2{" +
                "id=" + id +
                ", description='" + description + '\'' +
                '}';
    }
}
