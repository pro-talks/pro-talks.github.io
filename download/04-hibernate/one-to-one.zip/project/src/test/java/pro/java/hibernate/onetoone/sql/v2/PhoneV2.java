package pro.java.hibernate.onetoone.sql.v2;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity(name = "PhoneV2")
public class PhoneV2 {

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "number")
    private String number;

    @OneToOne(
            mappedBy = "phoneV2",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private PhoneDetailsV2 details;

    /*for hibernate*/
    public PhoneV2() {
    }

    public PhoneV2(String number) {
        this.number = number;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public PhoneDetailsV2 getDetails() {
        return details;
    }

    public void setDetails(PhoneDetailsV2 details) {
        this.details = details;
    }

    @Override
    public String toString() {
        return "PhoneV2{" +
                "id=" + id +
                ", number='" + number + '\'' +
                '}';
    }
}
