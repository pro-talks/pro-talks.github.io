package pro.java.hibernate.onetoone.sql.v2_1;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity(name = "PhoneDetailsV2_1")
public class PhoneDetailsV2_1 {

    @Id
    @GeneratedValue
    private Long id;

    private String description;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "phone_id")
    private PhoneV2_1 phoneV2_1;

    /*for hibernate*/
    public PhoneDetailsV2_1() {
    }

    public PhoneDetailsV2_1(String description) {
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PhoneV2_1 getPhoneV2_1() {
        return phoneV2_1;
    }

    public void setPhoneV2_1(PhoneV2_1 phoneV2_1) {
        this.phoneV2_1 = phoneV2_1;
    }

    @Override
    public String toString() {
        return "PhoneDetailsV2_1{" +
                "id=" + id +
                ", description='" + description + '\'' +
                '}';
    }
}
