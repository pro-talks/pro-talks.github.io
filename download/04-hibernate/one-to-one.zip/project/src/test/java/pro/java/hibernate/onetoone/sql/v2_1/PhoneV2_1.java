package pro.java.hibernate.onetoone.sql.v2_1;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@Entity(name = "PhoneV2_1")
public class PhoneV2_1 {

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "number")
    private String number;

    @OneToMany(
            mappedBy = "phoneV2_1",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY
    )
    private List<PhoneDetailsV2_1> details;

    /*for hibernate*/
    public PhoneV2_1() {
    }

    public PhoneV2_1(String number) {
        this.number = number;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public List<PhoneDetailsV2_1> getDetails() {
        return details;
    }

    public void setDetails(List<PhoneDetailsV2_1> details) {
        this.details = details;
    }

    public PhoneDetailsV2_1 getDetail() {
        return (details.isEmpty()) ? null : details.iterator().next();
    }

    public void addDetail(PhoneDetailsV2_1 detail) {
        if (details == null)
            details = new ArrayList<>();
        this.details.clear();
        this.details.add(detail);
    }

    @Override
    public String toString() {
        return "PhoneV2_1{" +
                "id=" + id +
                ", number='" + number + '\'' +
                '}';
    }
}
