package pro.java.hibernate.onetoone.sql.v3;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import static javax.persistence.FetchType.LAZY;

@Entity(name = "PhoneDetailsV3")
public class PhoneDetailsV3 {

    @Id
    private Long id;

    private String description;

    @MapsId
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "id")
    private PhoneV3 phoneV3;

    /*for hibernate*/
    public PhoneDetailsV3() {
    }

    public PhoneDetailsV3(String description) {
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PhoneV3 getPhoneV3() {
        return phoneV3;
    }

    public void setPhoneV3(PhoneV3 phoneV3) {
        this.phoneV3 = phoneV3;
    }

    @Override
    public String toString() {
        return "PhoneDetailsV3{" +
                "id=" + id +
                ", description='" + description + '\'' +
                '}';
    }
}
